import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buttons',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ButtonsComponent  {

  constructor() { }

}
