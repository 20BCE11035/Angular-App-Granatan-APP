export class Channel {

  title: string;
  name: string;
  releaseDate: string;

  constructor() {
    this.title = '';
    this.name = '';
    this.releaseDate = '';
  }

}
