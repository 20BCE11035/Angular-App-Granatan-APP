export class Params {

  public query: string;
  public page: string;

  constructor() {
    this.query = '';
    this.page = '';
  }

}
