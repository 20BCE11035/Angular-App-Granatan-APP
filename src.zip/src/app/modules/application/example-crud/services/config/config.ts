export class Config {

  public api: boolean;
  public url: string;

  constructor() {
    this.api = false;
    this.url = '';
  }

}
