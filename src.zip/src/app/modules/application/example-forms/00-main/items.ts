export const ITEMS: any[] =
  [
    { id: 1, name: 'prototype', link: 'prototype', icon: 'far fa-address-card' },
    { id: 2, name: 'form-control', link: 'form-control', icon: 'fas fa-user' },
    { id: 3, name: 'form-control-class', link: 'form-control-class', icon: 'fas fa-user-friends' },
    { id: 4, name: 'form-group', link: 'form-group', icon: 'fas fa-house-user' },
    { id: 5, name: 'form-builder', link: 'form-builder', icon: 'fab fa-app-store' },
    { id: 6, name: 'form-builder-nested', link: 'form-builder-nested', icon: 'fab fa-artstation' },
    { id: 7, name: 'form-array', link: 'form-array', icon: 'fab fa-asymmetrik' },
    { id: 8, name: 'form-multi', link: 'form-multi', icon: 'fas fa-atom' },
    { id: 9, name: 'single', link: 'single', icon: 'fab fa-centos' },
    { id: 10, name: 'multi', link: 'multi', icon: 'fas fa-chart-line' },
    { id: 11, name: 'init-class', link: 'init-class', icon: 'fas fa-cogs' },

  ];
