export class Item {
  public action: string;
  public emailebook: string;
  public data: any;
  constructor() {

    this.action = '';
    this.emailebook = '';

  }
}

