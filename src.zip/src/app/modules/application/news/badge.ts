export class Badge {
  name: string;
  caption: string;
  icon: string;

  constructor() {
    this.name = '';
    this.caption = '';
    this.icon = '';
  }
}
