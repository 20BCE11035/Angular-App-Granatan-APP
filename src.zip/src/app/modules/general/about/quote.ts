export class Quote {

  name: string;
  title: string;
  link: string;

  constructor() {
    this.name = '';
    this.title = '';
    this.link = '';
  }

}
