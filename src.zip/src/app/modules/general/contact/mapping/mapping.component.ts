import { Component } from '@angular/core';

@Component({
  selector: 'app-map',
  templateUrl: './mapping.component.html',
  styleUrls: ['./mapping.component.css']
})
export class MappingComponent {

  constructor() { }

}
